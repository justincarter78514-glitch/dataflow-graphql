# Data Flow Graph

A Node.js app that visualizes a data flow diagram using **GraphQL** as the data layer and SVG for rendering — matching the layout from your reference image.

## Quick Start

```bash
npm install
npm start
# Open http://localhost:3000
```

## Architecture

```
server.js          – Express server + GraphQL endpoint (/graphql)
src/schema.js      – GraphQL schema (NodeData, Edge, DataFlowGraph types)
public/index.html  – SVG canvas frontend that queries GraphQL
```

## GraphQL Schema

```graphql
enum NodeShape { DIAMOND | CIRCLE | RECTANGLE }
enum EdgeStyle { SOLID | DASHED }

type NodeData  { id, label, shape, image, x, y, group }
type Edge      { id, source, target, style }
type DataFlowGraph { nodes, edges }

type Query {
  graph: DataFlowGraph!        # full graph
  node(id: ID!): NodeData      # single node
  edges(nodeId: ID): [Edge!]!  # edges, optionally filtered by node
}
```

## Node Shapes

| Shape       | Use case              |
|-------------|----------------------|
| `DIAMOND`   | Standard service node |
| `CIRCLE`    | Central hub / broker  |
| `RECTANGLE` | Storage / data store  |

## Edge Styles

| Style    | Meaning                     |
|----------|-----------------------------|
| `SOLID`  | Same-cluster connection     |
| `DASHED` | Cross-cluster connection    |

## Interactivity

- **Click** a node to select it (highlighted border)
- **Hover** for a tooltip showing shape and group info
- **Drag** the canvas to pan
- **Scroll** to zoom in/out
- **Controls** (bottom-right): zoom in, zoom out, fit view

## Customizing Nodes & Edges

Edit `src/schema.js` — add to the `nodes` and `edges` arrays:

```js
// Add a node
{ id: 'n14', label: 'My Service', shape: 'DIAMOND', image: '🚀', x: 200, y: 300, group: 'left' }

// Add an edge
{ id: 'e16', source: 'n14', target: 'n5', style: 'DASHED' }
```

Then restart the server — the frontend auto-fetches via GraphQL on load.
