const express = require('express');
const { createHandler } = require('graphql-http/lib/use/express');
const { schema, root } = require('./src/schema');
const path = require('path');

const app = express();
const PORT = 3000;

// GraphQL endpoint
app.use('/graphql', createHandler({ schema, rootValue: root }));

// Serve frontend
app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => {
  console.log(`\n🚀 Data Flow Graph running at http://localhost:${PORT}`);
  console.log(`📡 GraphQL endpoint: http://localhost:${PORT}/graphql`);
});
